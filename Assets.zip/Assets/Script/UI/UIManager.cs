using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI comboText;

    void Start()
    {
        scoreText.text = "0";
        comboText.text = "COMBO 0";
    }
    public void UpdateScoreText(int score)
    {
        scoreText.text = score.ToString("N0");
    }
    public void UpdateComboText(int combo)
    {
        if (combo > 1)
        {
            comboText.text = $"COMBO {combo}";
            comboText.gameObject.SetActive(true);
        }
        else
        {
            comboText.gameObject.SetActive(false);
        }
    }
}
