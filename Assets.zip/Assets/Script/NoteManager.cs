using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class NoteManager : MonoBehaviour
{
    public static NoteManager Instance { get; private set; }
    private Dictionary<int, List<NoteBehavior>> activeNotes = new();
    private NoteBehavior[] heldLongNotes = new NoteBehavior[4];
    private CatcherController catcherController;
    private const float JUDGE_Y_POSITION = -4.0f;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        for (int i = 0; i < 4; i++) activeNotes.Add(i, new List<NoteBehavior>());
    }
    void Start() { catcherController = FindObjectOfType<CatcherController>(); }

    public void AddNote(NoteBehavior note)
    {
        if (activeNotes.ContainsKey(note.laneNumber)) activeNotes[note.laneNumber].Add(note);
    }
    public void StartJudge(int lane, float inputTime)
    {
        NoteBehavior n = FindClosestNote(lane);
        if (n != null)
        {
            JudgmentController.Instance.JudgeNote(n, inputTime);
            if (n.isLongNote) heldLongNotes[lane] = n;
        }
        else
        {
            JudgmentController.Instance.scoreManager.ResetCombo();
        }
    }
    public void EndJudge(int lane, float inputTime)
    {
        if (heldLongNotes[lane] != null) HandleNoteHit(heldLongNotes[lane]);
    }
    public void ProcessLongNoteTicks(float t)
    {
        for (int lane = 0; lane < 4; lane++)
        {
            if (catcherController.laneInputState[lane] && heldLongNotes[lane] != null)
                JudgmentController.Instance.ScoreLongNoteTick();
        }
    }
    public void HandleNoteHit(NoteBehavior note)
    {
        if (activeNotes.ContainsKey(note.laneNumber)) activeNotes[note.laneNumber].Remove(note);
        if (note.isLongNote && heldLongNotes[note.laneNumber] == note) heldLongNotes[note.laneNumber] = null;
        Destroy(note.gameObject);
    }
    public void HandleNoteMiss(NoteBehavior note)
    {
        JudgmentController.Instance.HandleMiss(note);
        HandleNoteHit(note);
    }
    private NoteBehavior FindClosestNote(int lane)
    {
        if (!activeNotes.ContainsKey(lane) || activeNotes[lane].Count == 0) return null;
        return activeNotes[lane].OrderBy(n => Mathf.Abs(n.transform.position.y - JUDGE_Y_POSITION)).FirstOrDefault();
    }
}
