using UnityEngine;

public class JudgmentController : MonoBehaviour
{
    public static JudgmentController Instance { get; private set; }
    public ScoreManager scoreManager;
    public float perfectRange = 0.08f, longNoteTickInterval = 0.1f;
    private float nextTickTime;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }
    private void Update()
    {
        if (Time.time >= nextTickTime)
        {
            NoteManager.Instance?.ProcessLongNoteTicks(Time.time);
            nextTickTime = Time.time + longNoteTickInterval;
        }
    }
    public void JudgeNote(NoteBehavior note, float inputTime)
    {
        float timeDifference = Mathf.Abs(inputTime - note.targetTime);
        if (timeDifference <= perfectRange)
        {
            scoreManager.IncreaseScore(100);
            scoreManager.IncreaseCombo();
            if (!note.isLongNote)
                NoteManager.Instance.HandleNoteHit(note);
        }
        else
        {
            scoreManager.ResetCombo();
            NoteManager.Instance.HandleNoteMiss(note);
        }
    }
    public void ScoreLongNoteTick() { scoreManager.IncreaseScore(5); }
    public void HandleMiss(NoteBehavior note) { }
}
