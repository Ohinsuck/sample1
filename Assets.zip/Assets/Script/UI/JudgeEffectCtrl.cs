using UnityEngine;

public class JudgeEffectCtrl : MonoBehaviour {
    public GameObject perfectFX, greatFX, goodFX, badFX, missFX;
    public void ShowEffect(string result) {
        switch (result) {
            case "Perfect": perfectFX.SetActive(true); break;
            case "Great": greatFX.SetActive(true); break;
            case "Good": goodFX.SetActive(true); break;
            case "Bad": badFX.SetActive(true); break;
            case "Miss": missFX.SetActive(true); break;
        }
    }
}
