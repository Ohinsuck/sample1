using UnityEngine;

public class CatcherLineCtrl : MonoBehaviour {
    private void OnTriggerEnter2D(Collider2D other) {
        if (other.CompareTag("Note")) {
            // 판정 처리 추후 구현
            Debug.Log("Note judged");
        }
    }
}
