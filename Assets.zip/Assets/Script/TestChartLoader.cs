using UnityEngine;

public class TestChartLoader : MonoBehaviour
{
    public GameObject standardNotePrefab;

    void Start()
    {
        SpawnNote(0, Time.time + 1f, false, 0f);
        SpawnNote(1, Time.time + 2f, true, 2f);
        SpawnNote(2, Time.time + 3f, false, 0f);
        SpawnNote(3, Time.time + 4f, false, 0f);
    }
    void SpawnNote(int lane, float targetTime, bool isLong, float duration)
    {
        var obj = Instantiate(standardNotePrefab, GetSpawnPosition(lane), Quaternion.identity, transform);
        var note = obj.GetComponent<NoteBehavior>();
        note.Initialize(targetTime, lane, isLong, duration);
        var rt = obj.GetComponent<RectTransform>();
        if (isLong)
        {
            rt.sizeDelta = new Vector2(rt.sizeDelta.x, 120 + duration * 80);
        }
    }
    Vector3 GetSpawnPosition(int lane)
    {
        float[] xs = { -1.5f, -0.5f, 0.5f, 1.5f };
        return new Vector3(xs[lane], 6f, 0f);
    }
}
