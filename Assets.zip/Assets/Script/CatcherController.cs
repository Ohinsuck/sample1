using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class CatcherController : MonoBehaviour
{
    public RectTransform catcherImg;
    public Image[] lineLights;
    private int laneIndex = 1;
    public float sectionWidth = 160f;
    private int laneCount = 4;
    public bool[] laneInputState = new bool[4];

    private void Start() => UpdateCatcherPos();

    public void CatcherMove(InputAction.CallbackContext ctx)
    {
        if (!ctx.performed) return;
        float dir = ctx.ReadValue<float>();
        laneIndex = Mathf.Clamp(laneIndex + (int)dir, 0, laneCount - 1);
        UpdateCatcherPos();
    }
    public void Lane1Judge(InputAction.CallbackContext ctx) { laneInputState[0] = ctx.performed; if (ctx.performed) TriggerImpact(0);}
    public void Lane2Judge(InputAction.CallbackContext ctx) { laneInputState[1] = ctx.performed; if (ctx.performed) TriggerImpact(1);}
    public void Lane3Judge(InputAction.CallbackContext ctx) { laneInputState[2] = ctx.performed; if (ctx.performed) TriggerImpact(2);}
    public void Lane4Judge(InputAction.CallbackContext ctx) { laneInputState[3] = ctx.performed; if (ctx.performed) TriggerImpact(3);}
    private void UpdateCatcherPos()
    {
        Vector2 pos = catcherImg.anchoredPosition;
        pos.x = sectionWidth * laneIndex;
        catcherImg.anchoredPosition = pos;
    }
    private void TriggerImpact(int lane) { /* lineLights[lane].color = Color.yellow; */ }
}
